


// ************************custom JS****************************

var name = document.getElementById('name')
var password = document.getElementById("pass")
function onLogin()
{
    var password = document.getElementById("pass")
    var name = document.getElementById('name')
    var invalid = document.getElementById("invalid")
    var invalid_pass = document.getElementById("invalid-pass")
    // console.log(name.value)
    // console.log(password.value)

    if(name.value === "" && password.value === "")
    {
        name.style.border = "1px solid red"
        password.style.border = "1px solid red";
        invalid.style.visibility = "visible"
        invalid_pass.style.visibility = "visible"
    }
    else if ( name.value === "")
    {
        name.style.border = "1px solid red"
        invalid.style.visibility = "visible"
    }
    else if(password.value === "")
    {
        password.style.border = "1px solid red";
        invalid_pass.style.visibility = "visible"
    }
    // localStorage.setItem("hello")

    var loginObj ={
        naam :name.value,
        secure : password.value
    } 
    console.log(loginObj)
}
// console.log(firebase)
 



var signup_name = document.getElementById("signup-name")
var signup_email = document.getElementById("signup-email")
var signup_pass = document.getElementById("signup-pass")
var signup_repeat = document.getElementById("signup-repeat")

function onSignup(){

var signup_name = document.getElementById("signup-name")
var signup_email = document.getElementById("signup-email")
var signup_pass = document.getElementById("signup-pass")
var signup_repeat = document.getElementById("signup-repeat")
var label_match = document.getElementById("label-pass")

console.log(signup_email.value)
console.log("calling like")

}

